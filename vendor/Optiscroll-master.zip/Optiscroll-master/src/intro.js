;(function ( window, document, Math, undefined ) {
  'use strict';
