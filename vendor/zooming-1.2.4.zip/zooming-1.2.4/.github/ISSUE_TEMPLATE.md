*For feature request or questions (please make sure to read through [Documentation](http://desmonding.me/zooming/docs/index.html)), ignore everything below. Remove this line also.*

I see an issue in [demo](http://desmonding.me/zooming/) page:

- OS: (Windows, OSX, Linux, iOS, Android...)
- Browser and version: (Chrome, Firefox, Safari, IE...)

Steps to reproduce:

1.
